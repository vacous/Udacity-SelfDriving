# -*- coding: utf-8 -*-
"""
Created on Fri Feb 17 22:34:03 2017

@author: Administrator
"""
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np 
from lane_helper import lane_help
import os
from moviepy.editor import VideoFileClip

# helper functions: analysis static picture
#reading in an image
def find_lane(input_image,bot_ratio=12,rho=1,theta=np.pi/180, threshold=5, min_line_len=2, max_line_gap=1):
    '''
    use the lane_help object to find the lane
    '''
    lane_detect = lane_help()
    lane_detect.grayscale(input_image)
    lane_detect.gaussian_blur(5)
    lane_detect.canny(50,100)
#    find the target image
#    Assumption: a trangle region with bottom of 3/4 image length 
#    height of half of the image height located at the center of the image 
    (image_height, image_width, _) = input_image.shape
    x_left_bot, x_right_bot, x_top = int(image_width/bot_ratio), int((bot_ratio-1)*image_width/bot_ratio), int(image_width/2)
    y_bot, y_top = image_height, int(image_height/2*1.05)
    INTEREST_REGION_TEST = [(x_left_bot, y_bot),(x_right_bot, y_bot),(x_top, y_top)]
    lane_detect.region_of_interest(INTEREST_REGION_TEST)
    lane_detect.hough_lines(rho, theta, threshold, min_line_len, max_line_gap)
    lane_detect.interpolate(12)
    image = lane_detect.weighted_img()
    return image
    
white_output = 'yellow.mp4'
clip1 = VideoFileClip("solidYellowLeft.mp4")
white_clip = clip1.fl_image(find_lane)
white_clip.write_videofile(white_output, audio=False)
    
# test image address 
all_image_address = ["test_images/" + each_address for each_address in os.listdir("test_images/")]

# check the function by ploting 
result_image = []
idx = 0
for each in all_image_address:
    each_image = mpimg.imread(each)
    result_image.append(find_lane(each_image,12))
    plt.figure(idx)
    plt.imshow(result_image[-1])
    idx += 1
##
