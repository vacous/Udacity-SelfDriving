Document List:
Report in PDF format
Report in ipython format
original python code 
3 result videos